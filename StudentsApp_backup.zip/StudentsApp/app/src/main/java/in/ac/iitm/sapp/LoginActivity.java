package in.ac.iitm.sapp;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class LoginActivity extends AppCompatActivity {

    SharedPreferences pref;
    public static String APP;
    public static String SERVER_LOGIN;
    public static final String ROLL_PATT = "^[a-zA-Z]{2}\\d{2}[a-zA-Z]\\d{3}$";
    public boolean darkTheme;
    EditText rollInput;
    EditText passInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        APP = this.getPackageName();
        SERVER_LOGIN = getString(R.string.server_login);

        pref = getSharedPreferences(APP, Context.MODE_PRIVATE);
        darkTheme = pref.getBoolean("darkTheme", false);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            if (darkTheme) {
                setTheme(R.style.AppThemeDark);
                getWindow().setNavigationBarColor(ContextCompat.getColor(this, R.color.colorBackDark));
            } else {
                getWindow().setNavigationBarColor(ContextCompat.getColor(this, R.color.colorBackLight));
            }
        }

        rollInput = findViewById(R.id.rollInput);
        passInput = findViewById(R.id.passInput);

        rollInput.setOnFocusChangeListener(new View.OnFocusChangeListener()  {
           public void onFocusChange(View v, boolean hasFocus) {
               if(hasFocus)  {
                   v.setAlpha(1.0f);
                   v.setBackgroundTintList(ContextCompat.getColorStateList(getApplicationContext(), (darkTheme) ? R.color.colorPrimary : R.color.colorPrimaryDark));
               }  else  {
                   v.setAlpha(0.5f);
                   v.setBackgroundTintList(ContextCompat.getColorStateList(getApplicationContext(), (darkTheme) ? R.color.colorText : R.color.colorTextDark));
               }
           }
        });

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signin);
    }

    public void validateAndLogin(View view)  {

        String roll = rollInput.getText().toString();
        String pass = rollInput.getText().toString();

        Matcher rp = Pattern.compile(ROLL_PATT).matcher(roll);

        if(pass.length() > 0 && rp.find())  {
            //attempt login
        }  else  {
            //say "NO"

        }

        //check if username and password are valid
        //then post to server

        //if can't connect, toast

        //else continue

        //if correct, take the returned data (with auth code) and put in offline storage
        //then launch main screen

        //if incorrect, indicate
        //if roll incorrect, animate roll bar
        //if pass incorrect, animate pass bar
        //create animation using VectorDrawable

        //LOGOUT: delete authcode when logging out from app (server)
        //delete app data
        //reset SharedPrefs
    }

    //OFFLINE DATA (SharedPrefs) NEEDS A LOGIN METHOD FIELD

    public void smailLogin(View view)  {
        //attempt smail login

        //if device login successful, check email agaist regex
        //QUIRK: aliased SMail will fail

        //if validated, send idToken to server, get auth code and data and store
        //SERVER: get email and validate from idToken, if valid perform steps as normal ldap login
        //launch main screen

        //if invalid, logout
        //notify user by toast of invalidity

        //if device login unsuccessful, notify user by toast

        //NOTE: remember to logout on device and delete authcode when logging out from app
        //LOGOUT: GLogout on device, delete authcode on server
        //delete data from app
    }
}
