package in.ac.iitm.sapp;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.AnimationUtils;

public class MainActivity extends AppCompatActivity {

    SharedPreferences pref;
    public static String APP;
    private boolean darkTheme = false;

    @SuppressLint("InlinedApi")
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        APP = this.getPackageName();
        setTheme(R.style.AppTheme);

        pref = getSharedPreferences(APP, Context.MODE_PRIVATE);
        boolean loggedIn = pref.getBoolean("loggedIn", false);
        darkTheme = pref.getBoolean("darkTheme", false);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            if (darkTheme) {
                setTheme(R.style.AppThemeDark);
                getWindow().setNavigationBarColor(ContextCompat.getColor(this, R.color.colorBackDark));
            } else {
                getWindow().setNavigationBarColor(ContextCompat.getColor(this, R.color.colorBackLight));
            }
        }

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if(loggedIn)  {
//            ConnectivityManager cm = (ConnectivityManager)context.getSystemService(Context.CONNECTIVITY_SERVICE);
//
//            NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
//            boolean isConnected = activeNetwork != null && activeNetwork.isConnectedOrConnecting();
//
//            if(isConnected)  {
//
//            }  else  {
//
//            }
            //start main activity
        }  else  {
            pref.edit().putBoolean("loggedIn", false).commit();
            //start login activity
            Intent intent = new Intent(this, LoginActivity.class);
            startActivity(intent);
        }

        //use SharedPreferences to check login, theme

        //if logged in, check internet connectivity

        //if connected, check session
        //if invalid, logout
        //if valid, keep logged in

        //if not, load data
    }

    @SuppressLint("ApplySharedPref")
    public void switchTheme(View view) {
        SharedPreferences pref = getSharedPreferences(APP, Context.MODE_PRIVATE);
        pref.edit().putBoolean("darkTheme", !darkTheme).commit();

        if(darkTheme)  {
            setTheme(R.style.AppThemeDark);
            getWindow().setNavigationBarColor(ContextCompat.getColor(this, R.color.colorBackDark));
        }  else  {
            getWindow().setNavigationBarColor(ContextCompat.getColor(this, R.color.colorBackLight));
        }

        recreate();

        view.startAnimation(AnimationUtils.loadAnimation(this, R.anim.shake));
    }
}
